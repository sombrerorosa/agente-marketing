# Design Taste

Use this reference when composition, typography, layout, color, or brand polish
matters.

## Contents

- Design Decision Loop
- Taste Modes
- Simplify Before Adding
- Composition Defaults
- Primitive Systems
- Anti-Generic Replacements
- Placement And Framing
- Typography
- Color And Material
- Data And Figures
- Brand-System Grammar
- Background And Generative Fields
- Production Polish
- Final Design Review

## Design Decision Loop

Before authoring a designed scene, define the message, focal subject, support
layer, accent system, and final-frame composition goal. If those choices are
not clear, the design will usually drift toward generic shapes.

- Translate "clean", "technical", or "premium" into a specific system: editorial
  light, product UI, schematic minimal, branded system map, dense dashboard
  detail, or presentation-grade explainer.
- Choose the taste mode before authoring: restrained product, institutional
  data, bold social, expressive primitive, playful character, or ambient field.
- Start with the fewest objects needed. A strong default is one focal subject,
  one support layer, and one accent system.
- Choose the main still image first. Motion should reveal and clarify that
  composition, not rescue a weak final frame.
- Decide which elements carry meaning. Decoration should either group content,
  show state, direct attention, reinforce brand, or be removed.
- Separate believability from density. Product or content detail is believable
  when state, workflow, labels, and hierarchy are internally consistent, not
  when the scene simply contains more interface fragments.
- If hierarchy, spacing, color restraint, object necessity, or final-frame
  quality fails, simplify and revise before finishing.

## Taste Modes

- Restraint-premium: neutral or one-hue palette, generous space, one functional
  accent, calm easing. Use for product, enterprise, technical, finance, and
  serious data.
- Commitment-premium: one word, number, mark, or object at full focus; two-tone
  or brand-locked color; beat-driven energy. Use for brand, social, title, and
  launch moments that need impact.
- Expressive primitive: one repeated shape, stroke, dot, glyph, cursor, or mark
  carries the idea. Use arrangement and gestalt before literal illustration.
- Ambient/generative: one anchor, one derived field, one ground. Keep the field
  quiet enough to host foreground content.
- Playful/character: use one emotional signature, such as blink, look, bounce,
  or squash. Keep the rest disciplined so charm does not become clutter.

## Simplify Before Adding

- Prefer fewer stronger objects over many meaningful-looking details.
- Remove, merge, resize, clarify, or rebalance existing elements before adding
  a new object, badge, line, glow, or texture.
- Treat a detail as valid only when it improves comprehension, hierarchy,
  workflow clarity, state, brand signal, or reading rhythm.
- A detail can have a role and still fail if the composition becomes crowded,
  evenly weighted, or hard to read.
- When the scene feels generic, first strengthen the focal subject, spacing,
  typography, and color roles. Add effects only after the composition holds.
- "Premium" most often fails by adding chrome: a framing card, a border, column
  dividers, a second surface tint, or a gradient. Treat the word as a cue to
  subtract. Strengthen scale, weight, brightness, and spacing first; reach for a
  container only if removing it would lose meaning.

## Primitive Systems

- Build richness from one primitive repeated or varied by scale, density,
  position, value, or timing.
- A single stroke, dot, ring, capsule, glyph, or geometric mark can become logo,
  texture, diagram, loader, or accent when used consistently.
- Density is acceptable when it is one motif multiplied. Many unrelated motifs
  read as clutter.
- If using an expressive primitive, make the arrangement carry meaning:
  overlap, orbit, chain, bracket, grid, radial order, or figure/ground.
- Avoid literal clip-art when an abstract relationship can explain the message
  more clearly.

## Composition Defaults

- Start with a clear hierarchy: primary subject, supporting detail, accent.
- Keep the object budget visible while designing: focal subject first, support
  second, accent last.
- Compose the first and final frames as intentional still designs.
- Use visual center, not only mathematical center. Round shapes, tall marks, and
  asymmetric logos may need optical nudging.
- Keep safe margins around text, logos, and overlays. Leave extra room for
  motion overshoot and blur-like effects.
- Use negative space as an active design element; do not fill every empty area.
- Align to a simple grid, baseline, or optical axis. Break alignment only when
  the concept clearly benefits.

## Anti-Generic Replacements

- Do not default to dark grids, blue arrows, empty cards, monospaced labels, or
  decorative circles for technical work. Use a chosen visual system with clear
  information hierarchy.
- Replace empty rounded cards with meaningful node details: icons, mini UI
  fragments, step numbers, labels, thumbnails, status marks, metrics, or data
  hints.
- Replace arbitrary accent circles with ports, badges, state indicators,
  handles, highlights, or remove them.
- Replace decorative grid wallpaper with structural alignment, section bands,
  subtle dividers, real axes, or whitespace.
- Replace generic glow with a focal halo, active-state emphasis, masked material
  pass, or no effect.

## Placement And Framing

- For transparent assets, frame the artwork tightly enough to feel usable but
  leave breathing room for motion.
- For full-frame scenes, keep the subject away from edges unless edge contact is
  part of the design.
- Preserve logo lockups. Do not change mark/wordmark proportions, spacing,
  rotation, or final alignment unless explicitly asked.
- Check whether the animation's final resting pose is the intended exported
  asset, not an in-between state.

## Typography

- Use one main type idea per composition: editorial, utilitarian, kinetic,
  playful, or premium.
- Decide the focal line or phrase before styling support text.
- Choose type for voice: serif for human/editorial authority, grotesque for
  product/function, monospace for technical labels, expressive type only when
  the words are the subject.
- Large light-weight type can feel more premium than heavy bold in restrained
  institutional scenes; heavy bold suits loud social and title work.
- Keep text readable at the intended size. Avoid crowding edges.
- Split long text into deliberate lines; do not let line breaks feel accidental.
- Establish type hierarchy with size, weight, case, and spacing before adding
  effects.
- Balance text blocks optically: line length, rag, weight, and spacing should
  feel stable in the final frame.
- When two text runs of different sizes share a row (label and value, name and
  number, icon and caption), align them by their cap-height centers, not by a
  shared baseline. A shared baseline makes the smaller run appear to sink. Center
  a single run inside a container by its cap-height box, not the em box or the
  baseline. See `player-contract.md` "Vector Text Vertical Placement" for the
  formula, since vector text has no auto-centering.
- Set vertical spacing between stacked text blocks relative to type size, not by
  eyeballed pixels. A workable default for a headline and the line directly below
  it is a gap of about 0.5 to 0.8 of the headline cap height; keep one consistent
  spacing step between sibling blocks so the rhythm reads deliberate.
- Use monospaced type only for code, data, terminals, or system-like content.
- Use weight, size, and timing before adding decorative elements.
- Convert to paths when exact font rendering matters and font support is
  uncertain.

## Color And Material

- Start from source/brand colors when provided.
- When no brand system is provided, prefer a premium pure black/white
  (`000`/`fff`) contrast or another deliberate premium palette; use warm
  near-black and cream/off-white tones only when the user asks for them.
- Use one dominant neutral or background, one primary color, and one accent
  unless the concept demands more.
- Assign color roles before adding new colors: background/neutral, focal
  subject, accent, and optional semantic state.
- Quarantine saturation to one expressive element, or make every color teach a
  category, state, comparison, or brand role.
- Do not let multiple accents compete for the same level of attention.
- Use tonal steps, hairlines, and brightness ramps for depth before shadows,
  glow, glass, or blur.
- Chrome/container budget is `0` by default. A framing card, container, border,
  or divider must do a job that whitespace and alignment cannot, or it is
  removed. Separate grids and columns with negative space and alignment first, a
  single hairline second, and a filled or bordered card last. Carry hierarchy
  with type weight, scale, brightness, and grouping, not with chrome.
- Use one surface tone. Do not stack two near-black or two near-white tints to
  fake a "surface"; layered low-contrast darks (or lights) read as a muddy box.
  If a card surface must differ from the background, make it one deliberate step
  with a clear purpose, not an arbitrary second tint.
- If dividers are genuinely needed, use one weight and one color for all of them,
  the title rule and any column rules included. Slightly different divider or
  border colors per element is a classic low-taste tell.
- Avoid muddy gradients, arbitrary glows, and decorative effects that reduce
  legibility.
- When using glass/metal/glow effects, keep the base composition readable with
  the effect removed.
- Verify color contrast on the intended background or transparent preview.

## Data And Figures

- The headline should state the insight; the chart or number confirms it.
- Pick the layout by the data job: hero figure, KPI grid, stat-card triad,
  comparison chart, progress card, dashboard metric, social proof, or heat map.
- Big figures should lead with extreme figure-to-label scale contrast.
- Default a stat triad to either even self-contained cards or borderless figures
  floating in negative space, separated by whitespace. Do not wrap the group in
  an extra outer framing card, and do not put dividers between the columns unless
  whitespace alone fails; if they are needed, use one hairline of one color
  between equal columns only.
- Direct-label values. Avoid forcing viewers to decode axes, legends, or chart
  clutter.
- Use one semantic accent against neutral, two values of one hue, or one
  saturated hue per card. Do not use rainbow color decoratively.
- Encode magnitude spatially when useful: size, bar height, strip width, ring
  nesting, heat rank, or actual-vs-goal contrast.
- Credibility comes from concrete scope signals: counts, source totals,
  outcome-tied logos, named people, or transparent caveats.

## Brand-System Grammar

- For multi-scene work, lock one layout skeleton, type system, and accent rule
  before designing variants.
- Use polarity flips, saturated-card variants, or theme slots for rhythm without
  inventing a new design language per scene.
- Apply the same restraint to utility content: timelines, address cards,
  event rows, and labels should use the same grid, hairlines, and type system.
- A recurring signature device can make a system ownable, but it must stay
  tonal or semantic instead of competing with the focal subject.

## Background And Generative Fields

- Build ambient fields from one anchor plus one derived field on one ground.
- Prefer fields generated from the subject, such as ripples, contours, or
  orbiting points, over generic motif scatter.
- Keep background fields type-free, low-contrast, and still-frame-clean unless
  the field itself is the deliverable.
- Use one motion archetype that fits the content: color cycle, path morph,
  drift and twinkle, staggered draw-on, radial emanation, or phase-offset wave.
- Make loops seamless and quiet enough that foreground content remains the
  hierarchy.

## Production Polish

- Check frame `0`, midpoint, and the final frame as design compositions.
- Treat first, midpoint, and final frames as the minimum still-frame check. For
  scenes with major semantic beats, also inspect the frames where a word lands,
  number resolves, logo locks up, chart completes, CTA appears, or camera move
  settles.
- The final frame should have one clear focal subject, readable support, and
  intentional negative space.
- The final frame should feel visually finished, not merely like the last
  rendered frame.
- Remove temporary construction shapes, debug colors, and placeholder names.
- Confirm no text, stroke, glow, or reveal mask clips during motion.
- Ensure the motion path and visual hierarchy point to the same subject.
- Prefer fewer, better elements over many weak accents.
- Reject placeholder-looking scenes even when they render correctly. If a node,
  label, or accent does not communicate meaning, refine it or remove it.
- Treat unresolved hierarchy, crowded detail, weak typography, color overload,
  or a poor final still as blockers. Revise the scene before considering it
  complete.

## Final Design Review

- Check focal point first: the viewer should know where to look before reading
  support labels or noticing accents.
- Check placement and spacing: margins, optical centering, baseline alignment,
  line breaks, and object spacing should feel deliberate at rest and during
  motion.
- Check hierarchy: scale, weight, brightness, spacing, and timing should make
  primary, support, and accent roles obvious.
- Check typography: line breaks, rag, casing, weight, tracking, and label
  placement should support the message rather than fill available space.
- Check vertical alignment and rhythm: mixed-size runs sharing a row should be
  cap-center aligned, single runs should be optically centered in their
  containers, and the spacing between a title and its subline (or any stacked
  blocks) should look intentional rather than tight or arbitrary. Inspect rows
  zoomed in, since small misalignments hide at full-frame scale.
- Check color roles: each saturated or high-contrast color should indicate
  brand, state, category, comparison, or focus.
- Check object necessity: remove, merge, resize, clarify, or rebalance weak
  elements before adding decoration, cards, glow, or extra detail.
- If the review fails, revise the composition and recheck the affected frames
  before finishing.

### Premium Restraint Checklist

Run this scan on any premium/clean/minimal/card scene before finishing:

- Zero unnecessary chrome: no framing card, border, or divider that whitespace
  and alignment could replace.
- Exactly one surface tone: no two stacked near-black or near-white tints.
- One divider treatment and one color, if any divider exists at all.
- Hierarchy reads from scale, weight, brightness, and spacing with all chrome
  removed.
- For each card, border, or divider present: would removing it lose meaning? If
  not, remove it.
